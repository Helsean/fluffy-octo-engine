<template>
    <div>
        <div v-if="isAuthenticated">
            <div>Добро пожаловать {{userName}}</div>
            <button @click="logout">Выйти</button>
        </div>

        <div v-else>
            <label>введите ваше имя:</label>
            <input v-model='userName' />
            <button @click="login">сохранить</button>
           
        </div>
    </div>
</template>


<script>

export default {
  name: 'HomeComp',
  data(){
    return {
        isAuthenticated: false,
        userName: ''
    }
  },
  methods: {
    login(){
        if(this.userName !== ''){
            this.isAuthenticated = true
            localStorage.setItem('isAuthenticated', true)
            localStorage.setItem('userName', this.userName)
            
            this.$router.push({
                name: 'Chat',
                query: {userName: this.userName}
            })
          } else {
            alert('напишите имя')
          }
        },

        logout(){
            this.isAuthenticated = false,
            this.userName = '',
            localStorage.removeItem('isAuthenticated'),
            localStorage.removeItem('userName')
        }
    },
    created(){
        if(localStorage.getItem('isAuthenticated')) {
            this.isAuthenticated = true,
            this.userName = localStorage.getItem('userName')
        }
    }
}
</script>
<style>
 
</style>