<template>
    <div class="flex">
      <input v-model="inputValue" type="text" class="input" placeholder="0">
      <ul class="list">
        <li v-for="num in numbers" :key="num" @click="inputValue += String(num)" class="list-item" >
          {{ num }}
        </li>
        <li v-for="op in operations" :key="op" @click="inputValue += String(op)" class="list-item op">
          {{ op }}
        </li>
        <li class="list-item op C" @click="inputValue = ''">
          C
        </li>
        <li class="list-item op res" @click="result">
          =
        </li>
      </ul>
    </div>
</template>


<script setup>

    import { ref } from 'vue'
    const inputValue = ref('')
    const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    const operations = ['+', '-', '*', '/']
    const result = () => {
       
        inputValue.value = eval(inputValue.value)
    }
    

</script>
<style>
 
</style>