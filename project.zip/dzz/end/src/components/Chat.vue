<template>
    <div v-if='userName'>
      <div class="chat">
      <h2>Чат</h2>
      <div class="text" v-for='msg in messages' :key="msg.id">
        {{msg.user}}: {{msg.text}}
        </div>
      <div v-show="emptyMsg" class="empty">текущих сообщений нет</div>
    </div>

    <input v-model="newMessage" placeholder="введите сообщение"/>
    <button @click="sendMessage">отправить</button>
    <button @click="delMessage">удалить</button>
    </div>

    <div v-else class="alert">
        для авторизации перейдите по <router-link :to='{name: "Home"}'>ссылке</router-link>
    </div>
</template>

<script>

export default {
  name: 'ChatComp',
  data(){
    return{
        messages: [],
        newMessage: '',
        emptyMsg: true,
        userName: localStorage.getItem('userName')
    }
  },
  methods:{
    sendMessage(){
        if(this.newMessage !== ''){
        this.emptyMsg = false;
        this.messages.push({id: new Date().getTime(), text: this.newMessage, user: this.userName})
       
       this.saveChatRecords()
       this.newMessage = ''

        } else {
            alert('пожалуйста введите сообщение')
        }
      },

      saveChatRecords(){
        const records = this.messages
        localStorage.setItem('messages_${this.userName}', JSON.stringify(records))
      },

      loadChatRecords(){
        const records = JSON.parse(localStorage.getItem('messages_${this.userName}'))
        if(records){
            this.messages = records
            this.emptyMsg = false
        }
      },

      delMessage(){
        this.messages = []
        localStorage.removeItem('messages_${this.userName}', JSON.stringify(this.messages))
        this.emptyMsg = true
      }
  },
  created(){
    this.loadChatRecords()
  }
}
</script>
<style>
h2 {
    color: pink;
    text-align: center;
}
.text {
    margin-bottom: 20px;
    color: pink;
}
.chat {
    widows: 500px;
    height: 100%;
    border: 5px solid pink;
    background-color: white;
    color: pink;
    font-weight: 18px;
    font-weight: bold;
}
.alert {
    color: pink;
}

</style>