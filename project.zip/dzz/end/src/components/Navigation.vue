<template>
    <div class="components">
        <nav>
            <router-link to='/'>Регистрация</router-link>
            <router-link to='/Chat'>Чат</router-link>
            <router-link to='/Calculator'>Калькулятор</router-link>
            <router-link to='/test'>Апи данные</router-link>
        </nav>
    </div>
</template>

<script>
export default {
  name: 'NavComp'
}
</script>

<style>

.components{
    background-color: pink;
    height: 100px;
    display: flex;
    justify-content: centr;
    width: 100%;
    
}
nav{
    width: 500px;
    height: 100%;
    display: flex;
    justify-content: space-between;
    align-itens: center;
    
}




</style>