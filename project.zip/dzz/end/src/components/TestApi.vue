<template>
    <div>
        <div>Команды</div>
        <div v-if='isLoad'>загрузка данных...</div>
        <div v-else>
            <div v-for='el in teamData' :key="el.id">
               {{el.id}}. {{el.abbreviation}} {{el.city}}
               <img
               srs="https://avatars.mds.yandex.net/i?id=5b90ab42978e9cdb5c1e6e3e1ebf69558c2c4445-10126262-images-thumbs&n=13"
               style="width: 15px; height: 15px"
               @click="removeTeam(el.id)"
               />

            </div>
        </div>
    </div>
</template>


<script>

export default {
  name: 'TestApi',
  data(){
    return {
        teamData: [],
        isLoad: true
    }
  },
  mounted(){
    const url = 'https://free-nba.p.rapidapi.com/teams?page=0';
    const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': '488f437511msh2d3854838388c55p13692cjsn135921cfebdf',
            'X-RapidAPI-Host': 'free-nba.p.rapidapi.com'
        }
    };

    fetch(url,options )
    .then((res) => res.json())
    .then((res) => {
        console.log(res.data);
        this.teamData = res.data
        this.isLoad = false
    })
  },

  methods: {
    removeTeam(id){
        this.teamData = this.teamData.filter((el) => el.id !== id)
    }
  }
}
</script>
<style>

</style>
 